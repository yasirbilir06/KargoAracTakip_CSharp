﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KargoAracTakip
{
    internal static class Program
    {
        /// <summary>
        /// Uygulamanın ana girdi noktası.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
        public static void kargo_aracı_SpeedExceeded(object sender, SpeedEventArgs e)
        {
            CargoVehicle arac = (CargoVehicle)sender;
            Console.WriteLine($"{arac.Plaka} plakalı {arac.Marka} marka kargo aracı hız limitini aştı.");
            Console.WriteLine($"Aracın hız limitini aştığı konum : {e.Latitude}° enlem ve {e.Longitude:F4}° boylam");
            Console.WriteLine($"Aracın şu anki konumu : {e.Latitude}° enlem ve {(e.Longitude + 200):F4}° boylam");
            Console.WriteLine($"{e.Time.ToString("dd.MM.yyyy HH:mm:ss")} anında aracın hızı = {e.Speed} olarak ölçüldü.");
        }


    }
}
