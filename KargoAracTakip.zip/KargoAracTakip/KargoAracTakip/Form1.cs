﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace KargoAracTakip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Form yüklendiğinde hız simülasyonunu başlatalım
            this.Load += Form1_Load;
        }

        // Form üzerine bir TextBox ekleyin ve adına 'txtOutput' verin.
        // TextBox'ın Multiline özelliğini 'true' yapın.

        private void Form1_Load(object sender, EventArgs e)
        {
            // Hız simülasyonunu başlat
            StartSpeedSimulation();
        }

        private void StartSpeedSimulation()
        {
            // Araçları oluşturuyoruz
            CargoVehicle kargo_aracı1 = new CargoVehicle("34EMG2002", "Bmw");
            CargoVehicle kargo_aracı2 = new CargoVehicle("06MYB1907", "Mercedes");

            // Olaylara abone oluyoruz
            kargo_aracı1.SpeedExceeded += new SpeedHandler(kargo_aracı_SpeedExceeded);
            kargo_aracı2.SpeedExceeded += new SpeedHandler(kargo_aracı_SpeedExceeded);

            // Hız simülasyonunu ayrı bir iş parçacığında çalıştırıyoruz
            Thread simulationThread = new Thread(() =>
            {
                for (byte i = 70; i <= 110; i += 5)
                {
                    kargo_aracı1.Speed = i;
                    kargo_aracı2.Speed = (byte)(i + 5);

                    // UI thread'ine dönerek çıktıları güncelliyoruz
                    this.Invoke((MethodInvoker)delegate
                    {
                        txtOutput.AppendText($"{kargo_aracı1.Plaka} plakalı aracın hızı = {kargo_aracı1.Speed}\r\n");
                        txtOutput.AppendText($"{kargo_aracı2.Plaka} plakalı aracın hızı = {kargo_aracı2.Speed}\r\n");
                    });

                    Thread.Sleep(1000); // 1 saniye bekleme
                }
            });

            simulationThread.IsBackground = true;
            simulationThread.Start();
        }

        private void kargo_aracı_SpeedExceeded(object sender, SpeedEventArgs e)
        {
            CargoVehicle arac = (CargoVehicle)sender;

            string output = $"{arac.Plaka} plakalı {arac.Marka} marka kargo aracı hız limitini aştı.\r\n" +
                            $"Aracın hız limitini aştığı konum : {e.Latitude}° enlem ve {e.Longitude:F4}° boylam\r\n" +
                            $"Aracın şu anki konumu : {e.Latitude}° enlem ve {(e.Longitude + 200):F4}° boylam\r\n" +
                            $"{e.Time.ToString("dd.MM.yyyy HH:mm:ss")} anında aracın hızı = {e.Speed} olarak ölçüldü.\r\n";

            // UI thread'ine dönerek çıktıları güncelliyoruz
            this.Invoke((MethodInvoker)delegate
            {
                txtOutput.AppendText(output);
            });
        }
    }
}