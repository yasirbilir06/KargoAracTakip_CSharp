﻿using System;
using KargoAracTakip;

public class CargoVehicle
{
    public string Plaka { get; set; }
    public string Marka { get; set; }

    private byte speed;
    public byte Speed
    {
        get { return speed; }
        set
        {
            speed = value;
            if (speed > 110)
            {
                OnSpeedExceeded();
            }
        }
    }

    public event SpeedHandler SpeedExceeded;

    public CargoVehicle(string plaka, string marka)
    {
        Plaka = plaka;
        Marka = marka;
        speed = 0;
    }

    protected virtual void OnSpeedExceeded()
    {
        if (SpeedExceeded != null)
        {
            // Örnek konum verileri (rastgele)
            double latitude = 0.0;
            Random rand = new Random();
            double longitude = rand.NextDouble() * 1_000_000;

            SpeedEventArgs args = new SpeedEventArgs(latitude, longitude, DateTime.Now, this.Speed);
            SpeedExceeded(this, args);
        }
    }
}