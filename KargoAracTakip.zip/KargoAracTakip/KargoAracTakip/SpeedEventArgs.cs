﻿using System;

public class SpeedEventArgs : EventArgs
{
    public double Latitude { get; set; }     // Enlem
    public double Longitude { get; set; }    // Boylam
    public DateTime Time { get; set; }       // Zaman
    public byte Speed { get; set; }          // Hız

    public SpeedEventArgs(double latitude, double longitude, DateTime time, byte speed)
    {
        Latitude = latitude;
        Longitude = longitude;
        Time = time;
        Speed = speed;
    }
}